# Yashvi Sompura - Luxury Architect Portfolio

A high-end, award-winning architect portfolio website featuring a luxurious black and gold theme with cinematic animations and premium UI/UX design.

## 🎨 Design Features

### Color Palette
- **Luxury Black**: #000000 (Primary background)
- **Royal Gold**: #C9A86A (Accent color)
- **Ivory**: #F4F4F4 (Text color)
- **Dark Separator**: #1A1A1A (Dividers)

### Typography
- **Headings**: Playfair Display (Elegant serif)
- **Body Text**: Inter (Clean sans-serif)
- **Accent Text**: Cinzel (Luxury uppercase)

### Premium Features
- ✨ Fullscreen cinematic hero with Ken Burns effect
- ✨ Letter-by-letter name reveal animation
- ✨ Custom gold cursor with hover effects
- ✨ Magnetic buttons with gold glow
- ✨ Smooth GSAP scroll animations
- ✨ Gold mask image reveal effects
- ✨ Interactive project cards with hover states
- ✨ Floating label contact form
- ✨ Editorial-style project case studies
- ✨ Fully responsive design

## 🚀 Getting Started

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the portfolio.

### Build for Production

```bash
npm run build
npm start
```

## 📁 Project Structure

```
yashvi-portfolio/
├── src/
│   └── app/
│       ├── components/
│       │   ├── Navigation.tsx          # Premium navigation bar
│       │   ├── HeroSection.tsx         # Cinematic hero with animations
│       │   ├── AboutSection.tsx        # Professional about layout
│       │   ├── ProjectsSection.tsx     # Interactive project grid
│       │   ├── ContactSection.tsx      # Luxury contact form
│       │   └── CustomCursor.tsx        # Gold custom cursor
│       ├── projects/
│       │   └── [id]/
│       │       └── page.tsx            # Project case study template
│       ├── globals.css                 # Premium design system
│       ├── layout.tsx                  # Root layout
│       └── page.tsx                    # Main homepage
├── public/
│   └── cv/                             # Place CV PDF here
└── package.json
```

## 📝 Content Customization

### Add Your CV
Place your CV PDF in: `public/cv/Yashvi_Sompura_CV.pdf`

### Update Personal Images
Replace placeholder images in:
- Hero section: Update `HeroSection.tsx` line 100
- About section portrait: Update `AboutSection.tsx` line 122
- Project images: Update `ProjectsSection.tsx` projects array

### Modify Projects
Edit the projects array in `src/app/components/ProjectsSection.tsx`:

```typescript
const projects: Project[] = [
  {
    id: 'your-project-id',
    title: 'Your Project Title',
    category: 'Project Category',
    location: 'Location',
    year: 'Year',
    image: 'path/to/image.jpg',
    description: 'Project description',
  },
  // Add more projects...
];
```

### Add Project Case Studies
Create new project data in `src/app/projects/[id]/page.tsx`:

```typescript
const projectsData: { [key: string]: ProjectData } = {
  'your-project-id': {
    id: 'your-project-id',
    title: 'Project Title',
    // ... other project details
  },
};
```

## 🎯 Key Sections

### 1. Hero Section
- Fullscreen hero with architectural background
- Animated name reveal (letter-by-letter)
- Gold underline animation
- Two CTA buttons (View Portfolio, Download CV)
- Scroll indicator with animation

### 2. About Section
- Professional portrait with gold border
- Biography text
- Skills displayed as gold capsules
- Availability status
- Smooth scroll animations

### 3. Projects Section
- Grid of 4 featured projects
- Hover effects with gold glow borders
- Slide-up title animations
- Links to detailed case studies
- "View All Projects" CTA

### 4. Contact Section
- Luxury contact form with floating labels
- Contact information display
- Social media links
- Location and availability info
- Gold ripple button animation

### 5. Project Case Study Pages
- Full-width hero image with reveal animation
- Project details (location, year, role, area, etc.)
- Concept description
- Image gallery with scroll animations
- Back to portfolio navigation

## 🌐 Deployment

### Deploy to Vercel (Recommended)

1. Push your code to GitHub
2. Import project on [Vercel](https://vercel.com)
3. Vercel will auto-detect Next.js and deploy

Or use Vercel CLI:

```bash
npm install -g vercel
vercel
```

### Environment Variables
None required for basic deployment.

## 🎨 Design System Classes

### Typography
- `.heading-primary` - Large hero headings
- `.heading-secondary` - Section headings
- `.heading-tertiary` - Subsection headings
- `.accent-text` - Gold uppercase accent text
- `.body-large` - Large body text
- `.body-regular` - Regular body text

### Buttons
- `.btn-gold-border` - Outlined gold button
- `.btn-gold-solid` - Filled gold button

### Components
- `.skill-capsule` - Skill tag with gold border
- `.floating-input` - Form input with floating label
- `.section-divider` - Horizontal gold divider
- `.gold-glow` - Gold shadow effect

## 📱 Responsive Design

The portfolio is fully responsive with breakpoints:
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🛠️ Technologies Used

- **Next.js 16** - React framework
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Utility-first CSS
- **GSAP** - Premium animations
- **Framer Motion** - React animations
- **React Icons** - Icon library

## 📧 Contact Information

Update contact details in:
- `src/app/components/ContactSection.tsx`
- Email: yashvia.sompura@gmail.com
- LinkedIn: linkedin.com/in/yashvitrivedi

## 🎓 License

© 2025 Yashvi Sompura. All Rights Reserved.

---

**Note**: Replace placeholder images with your actual portfolio images for the best presentation.
