'use client';

import { useEffect, useRef } from 'react';
import { useParams } from 'next/navigation';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { HiArrowLeft } from 'react-icons/hi2';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface ProjectData {
  id: string;
  title: string;
  category: string;
  location: string;
  year: string;
  role: string;
  heroImage: string;
  concept: string;
  images: string[];
  details: {
    area?: string;
    duration?: string;
    team?: string;
    software?: string[];
  };
}

export default function ProjectPage() {
  const params = useParams();
  const heroRef = useRef<HTMLDivElement>(null);

  // Sample project data - replace with actual data fetching
  const projectsData: { [key: string]: ProjectData } = {
    'metropolitan-housing': {
      id: 'metropolitan-housing',
      title: 'Metropolitan Housing',
      category: 'Residential Architecture',
      location: 'Mumbai, India',
      year: '2023',
      role: 'Lead Architect & Designer',
      heroImage: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070',
      concept:
        'A sustainable urban housing solution addressing the growing need for community-oriented living spaces in Mumbai. The design emphasizes natural ventilation, shared amenities, and flexible living spaces that adapt to modern lifestyles.',
      images: [
        'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070',
        'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?q=80&w=2070',
        'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?q=80&w=2070',
      ],
      details: {
        area: '25,000 sq ft',
        duration: '18 months',
        team: 'Lead design team of 4',
        software: ['AutoCAD', 'SketchUp', 'Enscape', 'Adobe Photoshop'],
      },
    },
  };

  const project = projectsData[params.id as string] || projectsData['metropolitan-housing'];

  useEffect(() => {
    // Hero image reveal animation
    gsap.fromTo(
      '.hero-reveal',
      { clipPath: 'inset(0 100% 0 0)' },
      {
        clipPath: 'inset(0 0% 0 0)',
        duration: 1.5,
        ease: 'power4.out',
        delay: 0.3,
      }
    );

    // Title fade in
    gsap.fromTo(
      '.project-title',
      { opacity: 0, y: 50 },
      { opacity: 1, y: 0, duration: 1, delay: 0.8, ease: 'power3.out' }
    );

    // Image reveals on scroll
    gsap.utils.toArray('.project-image').forEach((img: any) => {
      gsap.fromTo(
        img,
        { opacity: 0, y: 100 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: img,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    });
  }, []);

  return (
    <div className="min-h-screen bg-black">
      {/* Back Button */}
      <div className="fixed top-8 left-8 z-50">
        <Link
          href="/"
          className="flex items-center gap-2 text-[#C9A86A] hover:text-[#D4B77A] transition-colors duration-300"
        >
          <HiArrowLeft className="text-2xl" />
          <span className="accent-text text-xs">Back</span>
        </Link>
      </div>

      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen overflow-hidden">
        {/* Hero Image with Reveal */}
        <div className="hero-reveal absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url('${project.heroImage}')` }}
          />
          <div className="absolute inset-0 bg-black opacity-50" />
        </div>

        {/* Project Title Overlay */}
        <div className="project-title relative z-10 h-full flex items-end pb-20 px-6 md:px-12">
          <div className="max-w-7xl mx-auto w-full">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <span className="accent-text text-xs mb-4 block">{project.category}</span>
              <h1 className="heading-primary mb-6">{project.title}</h1>
              <div className="flex flex-wrap gap-8 text-sm text-[#F4F4F4] opacity-80">
                <div>
                  <span className="accent-text text-xs block mb-1">LOCATION</span>
                  <span>{project.location}</span>
                </div>
                <div>
                  <span className="accent-text text-xs block mb-1">YEAR</span>
                  <span>{project.year}</span>
                </div>
                <div>
                  <span className="accent-text text-xs block mb-1">ROLE</span>
                  <span>{project.role}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-6 md:px-12 py-24">
        {/* Concept */}
        <section className="mb-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <span className="accent-text text-xs mb-8 block">01 · CONCEPT</span>
            <p className="body-large leading-relaxed">{project.concept}</p>
          </motion.div>
        </section>

        {/* Project Details */}
        <section className="mb-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <span className="accent-text text-xs mb-8 block">02 · PROJECT DETAILS</span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {project.details.area && (
                <div className="border-l-2 border-[#C9A86A] pl-6">
                  <span className="text-xs text-[#C9A86A] uppercase tracking-widest block mb-2">
                    Area
                  </span>
                  <span className="body-regular">{project.details.area}</span>
                </div>
              )}
              {project.details.duration && (
                <div className="border-l-2 border-[#C9A86A] pl-6">
                  <span className="text-xs text-[#C9A86A] uppercase tracking-widest block mb-2">
                    Duration
                  </span>
                  <span className="body-regular">{project.details.duration}</span>
                </div>
              )}
              {project.details.team && (
                <div className="border-l-2 border-[#C9A86A] pl-6">
                  <span className="text-xs text-[#C9A86A] uppercase tracking-widest block mb-2">
                    Team
                  </span>
                  <span className="body-regular">{project.details.team}</span>
                </div>
              )}
              {project.details.software && (
                <div className="border-l-2 border-[#C9A86A] pl-6">
                  <span className="text-xs text-[#C9A86A] uppercase tracking-widest block mb-2">
                    Software
                  </span>
                  <span className="body-regular">{project.details.software.join(', ')}</span>
                </div>
              )}
            </div>
          </motion.div>
        </section>

        {/* Image Gallery */}
        <section className="mb-32">
          <span className="accent-text text-xs mb-12 block">03 · VISUALS</span>
          <div className="space-y-12">
            {project.images.map((image, index) => (
              <div key={index} className="project-image relative aspect-[16/10] overflow-hidden">
                <div
                  className="w-full h-full bg-cover bg-center"
                  style={{ backgroundImage: `url('${image}')` }}
                />
                {/* Gold corner accent */}
                <div className="absolute top-0 right-0 w-20 h-20 border-t-2 border-r-2 border-[#C9A86A] opacity-40" />
              </div>
            ))}
          </div>
        </section>

        {/* Navigation to Next Project */}
        <section className="border-t border-[#1A1A1A] pt-12">
          <Link
            href="/"
            className="group flex items-center justify-between hover:text-[#C9A86A] transition-colors duration-300"
          >
            <div>
              <span className="accent-text text-xs block mb-2">BACK TO</span>
              <span className="heading-tertiary">All Projects</span>
            </div>
            <HiArrowLeft className="text-4xl transform group-hover:-translate-x-2 transition-transform duration-300" />
          </Link>
        </section>
      </div>
    </div>
  );
}
