'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { HiArrowLeft } from 'react-icons/hi2';

export default function ProjectsPage() {
  return (
    <div className="min-h-screen bg-black py-24 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-[#C9A86A] hover:text-[#D4B77A] transition-colors duration-300 mb-12"
        >
          <HiArrowLeft className="text-2xl" />
          <span className="accent-text text-xs">Back to Home</span>
        </Link>

        {/* Page Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h1 className="heading-secondary mb-6">All Projects</h1>
          <p className="body-regular max-w-2xl mx-auto">
            Comprehensive portfolio of architectural and interior design projects.
          </p>
        </motion.div>

        {/* Projects will be listed here */}
        <div className="text-center text-[#F4F4F4] opacity-70">
          <p className="body-regular">
            Project gallery coming soon. Return to homepage to view featured projects.
          </p>
        </div>
      </div>
    </div>
  );
}
