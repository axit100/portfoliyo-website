import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Yashvi Sompura | Architect, Interior Designer & 3D Visualizer",
  description:
    "Luxury portfolio of Yashvi Sompura – Architect & Interior Designer based in Canada. Specializing in residential, cultural, and interior design with expertise in 3D visualization and construction coordination. Seeking on-site opportunities.",
  keywords: [
    "Architect",
    "Interior Designer",
    "3D Visualizer",
    "Architecture Portfolio",
    "Canada",
    "Residential Design",
    "Temple Architecture",
    "AutoCAD",
    "SketchUp",
    "Enscape",
    "Lumion",
  ],
  authors: [{ name: "Yashvi Sompura" }],
  openGraph: {
    title: "Yashvi Sompura | Architect & Interior Designer",
    description: "Award-winning architectural portfolio showcasing residential, cultural, and interior design projects",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
