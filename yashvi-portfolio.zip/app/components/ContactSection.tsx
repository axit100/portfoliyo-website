'use client';
import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { HiEnvelope } from 'react-icons/hi2';
import { FaLinkedin } from 'react-icons/fa';

export default function ContactSection() {
  const formRef = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => { setSubmitStatus('idle'); }, 5000);
    }, 2000);
  };

  return (
    <section className="relative w-full bg-black section-padding" id="contact">
      <div className="section-container">
        <div className="section-header">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} viewport={{ once: true }}>
            <span className="accent-text section-title">GET IN TOUCH</span>
            <h2 className="heading-secondary">Let's Build Something Beautiful</h2>
            <div className="section-subtitle">
              <p className="body-regular">Open to full-time, on-site opportunities in Canada. Available for architectural, interior design, and 3D visualization projects.</p>
            </div>
          </motion.div>
        </div>
        <div className="grid-responsive">
          <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} viewport={{ once: true }}>
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div className="floating-input"><input type="text" name="name" id="name" value={formData.name} onChange={handleChange} placeholder=" " required /><label htmlFor="name">Your Name</label></div>
              <div className="floating-input"><input type="email" name="email" id="email" value={formData.email} onChange={handleChange} placeholder=" " required /><label htmlFor="email">Email Address</label></div>
              <div className="floating-input"><input type="text" name="subject" id="subject" value={formData.subject} onChange={handleChange} placeholder=" " required /><label htmlFor="subject">Subject</label></div>
              <div className="floating-input"><textarea name="message" id="message" rows={6} value={formData.message} onChange={handleChange} placeholder=" " required className="resize-none" /><label htmlFor="message">Message</label></div>
              <button type="submit" disabled={isSubmitting} className={`btn-secondary w-full ${isSubmitting ? 'opacity-60 cursor-not-allowed' : ''}`}>{isSubmitting ? 'Sending...' : 'Send Message'}</button>
              {submitStatus === 'success' && (<motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center text-[#C9A86A] text-sm">Thank you! Your message has been sent successfully.</motion.div>)}
            </form>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} viewport={{ once: true }} className="space-y-12">
            <div className="space-y-8">
              <div><h3 className="heading-tertiary mb-8">Contact Information</h3></div>
              <div className="flex items-start gap-4"><div className="w-12 h-12 border border-[#C9A86A] flex items-center justify-center"><HiEnvelope className="text-[#C9A86A] text-xl" /></div><div><p className="accent-text text-xs mb-2">EMAIL</p><a href="mailto:yashvia.sompura@gmail.com" className="body-regular hover:text-[#C9A86A] transition-colors duration-300">yashvia.sompura@gmail.com</a></div></div>
              <div className="flex items-start gap-4"><div className="w-12 h-12 border border-[#C9A86A] flex items-center justify-center"><FaLinkedin className="text-[#C9A86A] text-xl" /></div><div><p className="accent-text text-xs mb-2">LINKEDIN</p><a href="https://www.linkedin.com/in/yashvitrivedi" target="_blank" rel="noopener noreferrer" className="body-regular hover:text-[#C9A86A] transition-colors duration-300">linkedin.com/in/yashvitrivedi</a></div></div>
              <div className="flex items-start gap-4"><div className="w-12 h-12 border border-[#C9A86A] flex items-center justify-center"><span className="text-[#C9A86A] text-lg">📍</span></div><div><p className="accent-text text-xs mb-2">LOCATION</p><p className="body-regular">Based in Canada</p><p className="text-sm text-[#F4F4F4] opacity-70 mt-1">Available for on-site roles</p></div></div>
            </div>
            <div className="border-l-2 border-[#C9A86A] pl-6 py-4"><p className="accent-text text-xs mb-3">CURRENTLY AVAILABLE</p><p className="body-regular mb-4">Seeking full-time architectural positions in Canada where I can contribute to impactful projects and grow alongside innovative teams.</p><p className="text-sm text-[#F4F4F4] opacity-80">Response time: Within 24 hours</p></div>
            <div><p className="accent-text text-xs mb-4">CONNECT</p><div className="flex gap-4"><a href="https://www.linkedin.com/in/yashvitrivedi" target="_blank" rel="noopener noreferrer" className="w-12 h-12 border border-[#C9A86A] flex items-center justify-center hover:bg-[#C9A86A] hover:text-black transition-all duration-300 group"><FaLinkedin className="text-xl" /></a><a href="mailto:yashvia.sompura@gmail.com" className="w-12 h-12 border border-[#C9A86A] flex items-center justify-center hover:bg-[#C9A86A] hover:text-black transition-all duration-300 group"><HiEnvelope className="text-xl" /></a></div></div>
          </motion.div>
        </div>
      </div>
      <motion.footer initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 1, delay: 0.5 }} viewport={{ once: true }} className="mt-32 text-center border-t border-[#1A1A1A] pt-12"><p className="accent-text text-xs mb-4">YASHVI SOMPURA</p><p className="text-sm text-[#F4F4F4] opacity-60">© 2025 All Rights Reserved. Designed & Developed with passion.</p></motion.footer>
    </section>
  );
}
