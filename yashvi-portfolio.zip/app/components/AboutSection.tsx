'use client';
import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
if (typeof window !== 'undefined') { gsap.registerPlugin(ScrollTrigger); }

export default function AboutSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const skills = ['AutoCAD', 'SketchUp', 'Enscape', 'Lumion', '3D Modeling', 'Space Planning', 'Working Drawings', 'Conceptual Design', 'Adobe Photoshop', 'Revit', 'Vray', 'Construction Coordination'];

  useEffect(() => {
    if (!sectionRef.current) return;
    gsap.fromTo(imageRef.current, { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 1.2, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', end: 'top 50%', toggleActions: 'play none none reverse' }});
    gsap.fromTo('.about-content', { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 70%', toggleActions: 'play none none reverse' }});
    gsap.fromTo('.skill-capsule', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: '.skills-container', start: 'top 85%', toggleActions: 'play none none reverse' }});
  }, []);

  return (
    <section ref={sectionRef} className="relative w-full bg-black section-padding" id="about">
    
      <div className="section-container">
        <div className="section-header">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} viewport={{ once: true }}>
            <span className="accent-text section-title">ABOUT ME</span>
            <h2 className="heading-secondary">Architectural Vision</h2>
          </motion.div>
        </div>
        <div className="grid-responsive items-center">
          <div ref={imageRef} className="relative">
            <div className="relative aspect-[3/4] overflow-hidden">
              <div className="absolute -top-4 -left-4 w-full h-full border-2 border-[#C9A86A] opacity-30 z-0" />
              <div className="relative w-full h-full bg-cover bg-center z-10" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=800')" }}>
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-40" />
              </div>
              <div className="absolute bottom-0 right-0 w-24 h-24 border-b-2 border-r-2 border-[#C9A86A]" />
            </div>
          </div>
          <div className="about-content space-y-8">
            <div className="space-y-6">
              <p className="body-large leading-relaxed">Architect & Interior Designer specializing in residential, cultural, and interior environments. Experienced in India and currently <span className="text-[#C9A86A] font-medium">based in Canada</span>.</p>
              <p className="body-regular leading-relaxed">Skilled in concept development, 3D visualization, construction drawings, and on-site coordination. My approach combines thoughtful spatial planning with meticulous attention to detail, creating designs that are both functional and emotionally resonant.</p>
              <p className="body-regular leading-relaxed">With experience across diverse project typologies—from metropolitan housing to cultural institutions and luxury interiors—I bring a comprehensive understanding of architecture at every scale.</p>
            </div>
            <div className="pt-4">
              <p className="accent-text text-sm mb-4">OPEN TO OPPORTUNITIES</p>
              <p className="body-regular">Currently seeking full-time, on-site architectural roles in Canada where I can contribute to meaningful projects and collaborate with innovative teams.</p>
            </div>
          </div>
        </div>
          <div className="section-divider" />
        <div className="skills-container mt-16 md:mt-20">
          <div className="text-center mb-8 md:mb-12"><span className="accent-text text-xs md:text-sm">EXPERTISE</span></div>
          <div className="section-divider" />
          <div className="flex flex-wrap justify-center gap-3 md:gap-4 max-w-4xl mx-auto">
            {skills.map((skill, index) => (<div key={index} className="skill-tag">{skill}</div>))}
          </div>
        </div>
      </div>
      <div className="section-divider" />
    </section>
  );
}
