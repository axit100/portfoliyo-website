'use client';

import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { motion } from 'framer-motion';

export default function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const underlineRef = useRef<HTMLDivElement>(null);
  const [titleRevealed, setTitleRevealed] = useState(false);

  useEffect(() => {
    gsap.to('.hero-image', {
      scale: 1.1,
      duration: 20,
      ease: 'none',
      repeat: -1,
      yoyo: true,
    });

    if (titleRef.current && !titleRevealed) {
      const letters = titleRef.current.querySelectorAll('.letter');

      gsap.fromTo(
        letters,
        { opacity: 0, y: 50, rotationX: -90 },
        {
          opacity: 1,
          y: 0,
          rotationX: 0,
          duration: 0.8,
          stagger: 0.05,
          ease: 'power4.out',
          delay: 0.5,
          onComplete: () => {
            setTitleRevealed(true);
            if (underlineRef.current) underlineRef.current.classList.add('active');
          },
        }
      );
    }

    gsap.fromTo('.hero-subtitle', { opacity: 0, y: 30 }, {
      opacity: 1,
      y: 0,
      duration: 1,
      delay: 1.5,
      ease: 'power3.out',
    });

    gsap.fromTo('.hero-description', { opacity: 0, y: 30 }, {
      opacity: 1,
      y: 0,
      duration: 1,
      delay: 1.8,
      ease: 'power3.out',
    });

    gsap.fromTo('.hero-buttons', { opacity: 0, y: 30 }, {
      opacity: 1,
      y: 0,
      duration: 1,
      delay: 2.1,
      ease: 'power3.out',
    });

    gsap.to('.scroll-indicator', {
      y: 10,
      duration: 1.5,
      ease: 'power1.inOut',
      repeat: -1,
      yoyo: true,
    });
  }, [titleRevealed]);

  const handleScroll = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) aboutSection.scrollIntoView({ behavior: 'smooth' });
  };

  const name = 'YASHVI TRIVEDI';
  const nameLetters = name.split('');

  return (
    <section
      ref={heroRef}
      id="hero"
      className="relative w-full h-screen overflow-hidden flex items-center justify-center"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div
          className="hero-image absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=2053')",
            transform: 'scale(1)',
          }}
        />
        <div className="absolute inset-0 bg-black opacity-60" />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, rgba(201,168,106,0.1) 0%, transparent 70%)',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full">
        <div className="container text-center">
        <motion.h1
          ref={titleRef}
          className="heading-primary mb-6"
          style={{ perspective: '1000px' }}
        >
          {nameLetters.map((letter, index) => (
            <span
              key={index}
              className="letter inline-block"
              style={{ display: 'inline-block', transformOrigin: 'bottom' }}
            >
              {letter === ' ' ? '\u00A0' : letter}
            </span>
          ))}
        </motion.h1>

        <div className="flex justify-center mb-8">
          <div
            ref={underlineRef}
            className="gold-underline"
            style={{ width: '0px', height: '2px' }}
          />
        </div>

        <p className="hero-subtitle accent-text mb-6 opacity-0">
          Architect | Interior Designer | 3D Visualizer
        </p>

        <div className="content-wrapper">
          <p className="hero-description body-large mb-12 opacity-0">
            Crafting meaningful spaces where creativity, comfort, and modern elegance converge seamlessly.
          </p>
        </div>

        <div className="hero-buttons flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center opacity-0">
          <button onClick={handleScroll} className="btn-primary w-full sm:w-auto">
            View Portfolio
          </button>

          <a
            href="/cv/Yashvi_Sompura_CV.pdf"
            download
            className="btn-secondary w-full sm:w-auto"
          >
            Download CV
          </a>
        </div>
      </div>
      </div>

      {/* Scroll Indicator */}
      <div className="scroll-indicator absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 opacity-70">
        <span className="accent-text text-xs">SCROLL</span>
        <div className="w-[1px] h-16 bg-gradient-to-b from-[#C9A86A] to-transparent" />
      </div>

      {/* Corner Decorations */}
      <div className="absolute top-8 left-8 w-16 h-16 border-t-2 border-l-2 border-[#C9A86A] opacity-30" />
      <div className="absolute top-8 right-8 w-16 h-16 border-t-2 border-r-2 border-[#C9A86A] opacity-30" />
      <div className="absolute bottom-8 left-8 w-16 h-16 border-b-2 border-l-2 border-[#C9A86A] opacity-30" />
      <div className="absolute bottom-8 right-8 w-16 h-16 border-b-2 border-r-2 border-[#C9A86A] opacity-30" />
    </section>
  );
}
