'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { HiMenu, HiX } from 'react-icons/hi';

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Contact', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-black/80 backdrop-blur-md border-b border-[#1A1A1A]'
            : 'bg-transparent'
        }`}
      >
        <div className="container">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link
              href="/"
              className="group flex flex-col"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#hero');
              }}
            >
              <span className="text-2xl md:text-3xl font-['Playfair_Display'] font-bold tracking-tight text-[#F4F4F4] group-hover:text-[#C9A86A] transition-colors duration-300">
                YASHVI
              </span>
              <span className="accent-text text-[8px] md:text-[9px] tracking-widest -mt-1">
                ARCHITECT
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-12">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => scrollToSection(item.href)}
                  className="accent-text text-xs hover:text-[#D4B77A] transition-colors duration-300 relative group"
                >
                  {item.name}
                  <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#C9A86A] group-hover:w-full transition-all duration-300" />
                </button>
              ))}
              
              {/* Download CV Button */}
              <a
                href="/cv/Yashvi_Sompura_CV.pdf"
                download
                className="px-6 py-2 border border-[#C9A86A] text-[#C9A86A] text-xs font-['Cinzel'] uppercase tracking-widest hover:bg-[#C9A86A] hover:text-black transition-all duration-300"
              >
                CV
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-[#C9A86A] text-3xl focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <HiX /> : <HiMenu />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed top-0 right-0 bottom-0 w-full bg-black/95 backdrop-blur-md border-l border-[#1A1A1A] z-50 md:hidden"
          >
            {/* Close Button */}
            <div className="flex justify-end p-6">
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="text-[#C9A86A] text-3xl"
                aria-label="Close menu"
              >
                <HiX />
              </button>
            </div>

            {/* Mobile Navigation Items */}
            <div className="flex flex-col items-center gap-6 mt-8 px-6">
              {navItems.map((item, index) => (
                <motion.button
                  key={item.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => scrollToSection(item.href)}
                  className="accent-text text-lg hover:text-[#D4B77A] transition-colors duration-300"
                >
                  {item.name}
                </motion.button>
              ))}

              {/* Download CV Button Mobile */}
              <motion.a
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                href="/cv/Yashvi_Sompura_CV.pdf"
                download
                className="mt-8 px-8 py-3 border-2 border-[#C9A86A] text-[#C9A86A] text-sm font-['Cinzel'] uppercase tracking-widest hover:bg-[#C9A86A] hover:text-black transition-all duration-300"
              >
                Download CV
              </motion.a>
            </div>

            {/* Decorative Elements */}
            <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 w-32 h-32 border border-[#C9A86A] opacity-10" />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
