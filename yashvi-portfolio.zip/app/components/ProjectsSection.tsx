'use client';
import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { HiArrowRight } from 'react-icons/hi2';
if (typeof window !== 'undefined') { gsap.registerPlugin(ScrollTrigger); }

interface Project { id: string; title: string; category: string; location: string; year: string; image: string; description: string; }

export default function ProjectsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);
  const projects: Project[] = [
    { id: 'metropolitan-housing', title: 'Metropolitan Housing', category: 'Residential Architecture', location: 'Mumbai, India', year: '2023', image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070', description: 'Urban housing development focused on community and sustainability' },
    { id: 'subterranean-cultural-hub', title: 'Subterranean Cultural Hub', category: 'Thesis Project', location: 'Conceptual', year: '2023', image: 'https://images.unsplash.com/photo-1577495508326-19a1b3cf65b7?q=80&w=2074', description: 'Underground cultural center exploring innovative spatial experiences' },
    { id: 'temple-architecture', title: 'Temple Architecture', category: 'Religious & Cultural', location: 'Various Locations', year: '2022-2023', image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=2070', description: 'Sacred spaces blending traditional design with contemporary execution' },
    { id: 'luxury-interiors', title: 'Residential & Interior Projects', category: 'Interior Design', location: 'India', year: '2020-2022', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?q=80&w=2074', description: 'High-end residential interiors with bespoke furniture and finishes' },
  ];

  useEffect(() => {
    if (!sectionRef.current) return;
    gsap.fromTo('.project-card', { opacity: 0, y: 80 }, { opacity: 1, y: 0, duration: 1, stagger: 0.2, ease: 'power3.out', scrollTrigger: { trigger: '.projects-grid', start: 'top 80%', toggleActions: 'play none none reverse' }});
  }, []);

  return (
    <section ref={sectionRef} className="relative w-full bg-black section-padding" id="projects">
      <div className="section-container">
        <div className="section-header">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} viewport={{ once: true }}>
            <span className="accent-text section-title">PORTFOLIO</span>
            <h2 className="heading-secondary">Selected Works</h2>
            <div className="section-subtitle">
              <p className="body-regular">A collection of architectural and interior design projects spanning residential, cultural, and institutional typologies.</p>
            </div>
          </motion.div>
        </div>
        <div className="projects-grid grid-responsive">
          {projects.map((project) => (
            <Link key={project.id} href={`/projects/${project.id}`} className="project-card group relative block" onMouseEnter={() => setHoveredProject(project.id)} onMouseLeave={() => setHoveredProject(null)}>
              <div className="relative aspect-[4/5] overflow-hidden bg-[#1A1A1A]">
                <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 ease-out group-hover:scale-110" style={{ backgroundImage: `url('${project.image}')` }} />
                <div className="absolute inset-0 bg-black opacity-40 group-hover:opacity-60 transition-opacity duration-500" />
                <div className={`absolute inset-0 border-2 border-[#C9A86A] transition-all duration-500 ${hoveredProject === project.id ? 'opacity-100 scale-100 gold-glow' : 'opacity-0 scale-95'}`} />
                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-3"><span className="accent-text text-xs">{project.category}</span></motion.div>
                  <motion.h3 initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="heading-tertiary mb-3 transform group-hover:translate-y-[-8px] transition-transform duration-500">{project.title}</motion.h3>
                  <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="flex items-center gap-4 text-sm text-[#F4F4F4] opacity-80 mb-4"><span>{project.location}</span><span>•</span><span>{project.year}</span></motion.div>
                  <div className={`overflow-hidden transition-all duration-500 ${hoveredProject === project.id ? 'max-h-24 opacity-100' : 'max-h-0 opacity-0'}`}><p className="body-regular text-sm mb-4">{project.description}</p></div>
                  <div className={`flex items-center gap-2 text-[#C9A86A] transition-all duration-500 ${hoveredProject === project.id ? 'translate-x-0 opacity-100' : 'translate-x-[-20px] opacity-0'}`}><span className="accent-text text-xs">View Case Study</span><HiArrowRight className="text-lg transform group-hover:translate-x-2 transition-transform duration-300" /></div>
                </div>
                <div className="absolute top-4 right-4 w-8 h-8 border-t border-r border-[#C9A86A] opacity-0 group-hover:opacity-60 transition-opacity duration-500" />
                <div className="absolute bottom-4 left-4 w-8 h-8 border-b border-l border-[#C9A86A] opacity-0 group-hover:opacity-60 transition-opacity duration-500" />
              </div>
            </Link>
          ))}
        </div>
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.6 }} viewport={{ once: true }} className="text-center mt-16">
          <Link href="/projects" className="btn-primary">View All Projects</Link>
        </motion.div>
      </div>
      <div className="section-divider" />
    </section>
  );
}
