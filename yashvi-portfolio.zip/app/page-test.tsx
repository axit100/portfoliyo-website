export default function Home() {
  return (
    <div>
      <h1>Test Page</h1>
      <p>If you see this, the page is working</p>
    </div>
  );
}
