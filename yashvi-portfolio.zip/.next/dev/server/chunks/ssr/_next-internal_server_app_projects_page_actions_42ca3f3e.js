module.exports = [
"[project]/.next-internal/server/app/projects/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_projects_page_actions_42ca3f3e.js.map