(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_components_fa7bfdcd._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_fdd5ade6._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_94c5f7f2._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_gsap_f48a6384._.js",
  "static/chunks/node_modules_0f0b5b4e._.js"
],
    source: "dynamic"
});
