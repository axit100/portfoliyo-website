(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_b71551f1._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_94c5f7f2._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_0f0b5b4e._.js",
  "static/chunks/app_projects_page_tsx_83f2937c._.js"
],
    source: "dynamic"
});
