# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

This is an architect portfolio website for Yashvi Sompura, built with Next.js 16 (App Router), React 19, TypeScript, and Tailwind CSS v4. The site is intended for deployment on Vercel and showcases architecture, interior design, and 3D visualization work.

## Tech Stack

- **Framework**: Next.js 16.0.3 with App Router
- **React**: v19.2.0
- **TypeScript**: v5 (strict mode enabled)
- **Styling**: Tailwind CSS v4 with custom theme integration
- **Fonts**: Geist Sans and Geist Mono (via next/font)
- **Deployment Target**: Vercel

## Common Commands

### Development
```bash
npm run dev
# Starts development server at http://localhost:3000
# App Router enables hot reload on file changes
```

### Build & Production
```bash
npm run build      # Creates production build
npm start          # Runs production server (after build)
```

### Linting
```bash
npm run lint
# Note: ESLint is currently disabled for this project
# The lint command outputs a message confirming this
```

## Project Structure

```
yashvi-portfolio/
├── src/
│   └── app/              # Next.js App Router directory
│       ├── layout.tsx    # Root layout with metadata & fonts
│       ├── page.tsx      # Main portfolio page (single-page design)
│       ├── globals.css   # Tailwind imports & CSS custom properties
│       └── favicon.ico
├── public/               # Static assets (SVG icons)
├── next.config.ts        # Next.js configuration (minimal)
├── tsconfig.json         # TypeScript config with path aliases (@/*)
└── package.json          # Scripts and dependencies
```

## Architecture Notes

### Single-Page Design
The entire portfolio is a single page (`src/app/page.tsx`) with anchor-linked sections:
- Top/Hero
- About
- Education
- Skills
- Experience
- Projects
- Contact

Navigation is handled via in-page hash links (`#about`, `#education`, etc.).

### Layout & Metadata
- Root layout (`src/app/layout.tsx`) defines global metadata (title, description) for SEO
- Uses Next.js font optimization with Geist fonts
- Supports automatic dark mode via CSS custom properties

### TypeScript Configuration
- Path alias `@/*` maps to `./src/*` for cleaner imports
- Strict mode enabled
- Target: ES2017
- JSX: react-jsx (React 19 automatic runtime)

### Styling Approach
- Tailwind CSS v4 with inline theme configuration in `globals.css`
- Custom properties: `--background`, `--foreground`, `--font-geist-sans`, `--font-geist-mono`
- Responsive design: mobile-first with `md:` and `lg:` breakpoints
- Dark mode support via `prefers-color-scheme`

## Development Guidelines

### When Adding New Content
- Projects and images should be added to the Projects section in `src/app/page.tsx`
- Keep the single-page structure; avoid creating new routes unless adding blog/CMS
- Static assets go in `public/` and are referenced with `/filename.ext`

### TypeScript
- Always use TypeScript for new files
- Leverage existing types from Next.js (`Metadata`, `NextConfig`)
- Import types explicitly: `import type { ... }`

### Styling
- Use Tailwind utility classes consistently
- Follow existing patterns: neutral color palette, uppercase tracking for headings
- Maintain responsive design patterns (flex-col on mobile, flex-row on desktop)

### Deployment
- This project is intended for Vercel deployment
- Vercel auto-detects Next.js and uses `npm run build`
- No additional configuration needed for basic deployment
- Environment variables (if needed) should be set in Vercel dashboard

## Important Constraints

- **No ESLint**: Linting is disabled; rely on TypeScript for type checking
- **No Testing Framework**: No test scripts are configured
- **React 19**: Use React 19 features and conventions (automatic JSX runtime)
- **App Router Only**: Do not use Pages Router patterns
