# Deployment Guide - Yashvi Portfolio

## 🚀 Deploy to Vercel (Recommended)

Vercel is the recommended platform for deploying Next.js applications. It's created by the team behind Next.js and offers seamless integration.

### Method 1: Using Vercel Dashboard (Easiest)

1. **Push Code to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit - Luxury architect portfolio"
   git push origin main
   ```

2. **Import to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Sign up/Login with GitHub
   - Click "Add New Project"
   - Import your `yashvi-portfolio` repository
   - Vercel will auto-detect Next.js settings
   - Click "Deploy"
   - Your site will be live in ~2 minutes!

3. **Custom Domain (Optional)**
   - Go to Project Settings → Domains
   - Add your custom domain (e.g., yashvisompura.com)
   - Follow DNS configuration instructions

### Method 2: Using Vercel CLI

```bash
# Install Vercel CLI globally
npm install -g vercel

# Deploy from project root
vercel

# Follow prompts:
# - Link to existing project or create new
# - Choose default settings
# - Deployment will start automatically

# For production deployment
vercel --prod
```

## 🌐 Alternative Deployment Options

### Netlify

1. Push code to GitHub
2. Visit [netlify.com](https://netlify.com)
3. Click "Add new site" → "Import from Git"
4. Select repository
5. Build settings:
   - Build command: `npm run build`
   - Publish directory: `.next`
6. Deploy!

### Deploy to VPS (Advanced)

```bash
# Build the application
npm run build

# Start production server
npm start

# Or use PM2 for process management
npm install -g pm2
pm2 start npm --name "yashvi-portfolio" -- start
```

## ⚙️ Pre-Deployment Checklist

### 1. Update Personal Content

- [ ] Replace hero background image in `HeroSection.tsx`
- [ ] Add your professional photo in `AboutSection.tsx`
- [ ] Update project images in `ProjectsSection.tsx`
- [ ] Add your CV PDF to `public/cv/Yashvi_Sompura_CV.pdf`
- [ ] Verify contact information in `ContactSection.tsx`

### 2. Test Locally

```bash
# Test development build
npm run dev

# Test production build
npm run build
npm start
```

Visit `http://localhost:3000` and check:
- [ ] All sections load properly
- [ ] Animations work smoothly
- [ ] Navigation is functional
- [ ] Contact form displays correctly
- [ ] Project links work
- [ ] Responsive design on mobile

### 3. Optimize for Production

Already included:
- ✅ Image optimization via Next.js
- ✅ Code splitting
- ✅ CSS minification
- ✅ Font optimization

## 🔧 Environment Configuration

No environment variables required for basic deployment.

### Optional: Add Analytics

If you want to add Google Analytics:

1. Install package:
```bash
npm install @next/third-parties
```

2. Add to `layout.tsx`:
```typescript
import { GoogleAnalytics } from '@next/third-parties/google'

export default function RootLayout({ children }) {
  return (
    <html>
      <body>{children}</body>
      <GoogleAnalytics gaId="G-XXXXXXXXXX" />
    </html>
  )
}
```

## 📊 Performance Optimization

### Already Implemented:
- Lazy loading images
- Code splitting by route
- CSS-in-JS optimization
- Font preloading
- Smooth scroll behavior
- Optimized animations with GSAP

### Additional Tips:
1. Use WebP format for images (better compression)
2. Compress images before uploading (TinyPNG, ImageOptim)
3. Keep total page size under 3MB

## 🔍 SEO Configuration

Already included in `layout.tsx`:
- ✅ Meta description
- ✅ Keywords
- ✅ Open Graph tags
- ✅ Semantic HTML

### Add More (Optional):

```typescript
// In layout.tsx
export const metadata: Metadata = {
  // ... existing metadata
  robots: 'index, follow',
  googlebot: 'index, follow',
  canonical: 'https://yashvisompura.com',
}
```

## 🐛 Troubleshooting

### Build Errors

**Error: Module not found**
```bash
# Clear cache and reinstall
rm -rf .next node_modules
npm install
npm run build
```

**GSAP Animation Issues**
- Ensure all GSAP animations use `'use client'` directive
- Check ScrollTrigger is registered before use

### Deployment Issues

**Vercel build fails**
- Check build logs in Vercel dashboard
- Ensure all dependencies are in `package.json`
- Verify Next.js version compatibility

**Images not loading**
- Use absolute paths for images in `public/`
- Configure `next.config.ts` for external images:

```typescript
const nextConfig = {
  images: {
    domains: ['images.unsplash.com', 'yourdomain.com'],
  },
}
```

## 📱 Testing Checklist

Before going live:

- [ ] Test on Chrome, Firefox, Safari, Edge
- [ ] Test on mobile (iOS and Android)
- [ ] Test on tablet
- [ ] Verify all links work
- [ ] Check loading speed (aim for < 3s)
- [ ] Test contact form
- [ ] Verify CV download works
- [ ] Check social media links
- [ ] Test navigation smooth scroll

## 🎯 Post-Deployment

1. **Share Your Portfolio**
   - Update LinkedIn with portfolio link
   - Add to resume/CV
   - Share on architecture platforms

2. **Monitor Performance**
   - Use Vercel Analytics (free)
   - Google PageSpeed Insights
   - Monitor form submissions

3. **Keep Updated**
   - Add new projects regularly
   - Update work experience
   - Refresh images seasonally

## 📞 Support

If you encounter issues:
1. Check the [Next.js Documentation](https://nextjs.org/docs)
2. Review [Vercel Documentation](https://vercel.com/docs)
3. Check GitHub Issues for similar problems

---

**Deployment URL Structure:**
- Homepage: `https://yoursite.com`
- Projects: `https://yoursite.com/projects`
- Project Detail: `https://yoursite.com/projects/metropolitan-housing`

**Expected Build Time:** 1-2 minutes  
**Expected Deploy Time:** 30 seconds

🎉 **Your luxury portfolio is ready to impress the world!**
